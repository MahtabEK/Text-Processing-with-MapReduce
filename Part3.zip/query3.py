#!/usr/bin/env python
# coding: utf-8

# In[1]:


with open('3out.txt', 'r') as file:
    data = file.read().replace('\n', '') 
data = data.split("('")

index = {}
for i in range(len(data)):
    f = data[i].split(",")
    genre = f[0]  
    index[genre]=f
    


# In[11]:


query = "short And Horror"


# In[12]:


query = query.lower()
query = query.split()

if len(query) == 1:
    query1 = query[0]
    query1 = query1 + "'"
    listOfMovie1 = index[query1]
    if listOfMovie1:
        print(listOfMovie1)
    else:
        print("No Movies found")
    
elif len(query) == 3:
    query1 = query[0];
    query1 = query1 + "'"
    
    query2 = query[2];
    query2 = query2 + "'"
    
    operator = query[1]
    
    listOfMovie1 = index[query1]
    listOfMovie2 = index[query2]
    
    a_set = set(listOfMovie1) 
    b_set = set(listOfMovie2) 
    
    if operator == "and":
        if (a_set & b_set): 
            print(a_set & b_set) 
        else: 
            print("No Movies")  
    
    elif operator == "or":
        if (a_set | b_set): 
            print(a_set | b_set) 
        else: 
            print("No Movies")


# In[ ]:




