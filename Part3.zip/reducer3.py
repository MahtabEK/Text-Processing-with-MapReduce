#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python

from operator import itemgetter
import sys

current_movie_genre = None
current_movie_name = []
movie_genre = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    movie_genre, movie_name = line.split('\t')
  
  
    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_movie_genre == movie_genre:
        current_movie_name.append(movie_name)
    else:
        if current_movie_genre:
            # write result to STDOUT
            print(current_movie_genre, current_movie_name)
            print("\n")
        current_movie_name=[]
        current_movie_name.append(movie_name)
        current_movie_genre = movie_genre

# do not forget to output the last word if needed!
if current_movie_genre == movie_genre:
    print(current_movie_genre, current_movie_name)
    print("\n")
    


# In[ ]:

