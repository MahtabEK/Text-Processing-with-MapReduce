#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/python

import sys

# input comes from STDIN (standard input)
for line in sys.stdin:
    line = line.strip()
    line = line.split("::")
    
    if line[2] == '':
        line[2] = "None"
        
    movie_genre = line[2].split("|")
    movie_name = line[1]
    
    for genre in movie_genre:
        genre = genre.lower()
        print '%s\t%s' % (genre, movie_name)


