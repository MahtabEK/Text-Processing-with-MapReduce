#!/usr/bin/env python
# coding: utf-8

# In[1]:


index={}
file = open('movies.txt')
mylist = [line.rstrip('\n') for line in file]


for line in mylist:
    line = line.split("::")
    
    if line[2] == '':
        line[2] = "none"
        
    movie_genre = line[2].split("|")
    
    for genre in movie_genre:
        genre = genre.lower()
        if index.get(genre, None) == None:
            index[genre] = [line[1]]
        else:
            index[genre].append(line[1])

query = "Short and Drama"
query = query.lower()
query = query.split()

if len(query) == 1:
    query1 = query[0]
    listOfMovie1 = index[query1]
    if listOfMovie1:
        print(listOfMovie1)
    else:
        print("No Movies found")
    
elif len(query) == 3:
    query1 = query[0];
    query2 = query[2];
    operator = query[1]
    listOfMovie1 = index[query1]
    listOfMovie2 = index[query2]
    
    a_set = set(listOfMovie1) 
    b_set = set(listOfMovie2) 
    
    if operator == "and":
        if (a_set & b_set): 
            print(a_set & b_set) 
        else: 
            print("No Movies")  
    
    elif operator == "or":
        if (a_set | b_set): 
            print(a_set | b_set) 
        else: 
            print("No Movies")


