#!/usr/bin/env python
# coding: utf-8

# In[2]:


index={}
file = open('movies.txt')
mylist = [line.rstrip('\n') for line in file]


for line in mylist:
    line = line.split("::")
    
    if line[2] == '':
        line[2] = "none"
        
    movie_genre = line[2].split("|")
    
    for genre in movie_genre:
        genre = genre.lower()
        if index.get(genre, None) == None:
            index[genre] = [line[1]]
        else:
            index[genre].append(line[1])
            
print(index)


# In[ ]:




