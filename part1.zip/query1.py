#!/usr/bin/env python
# coding: utf-8

# In[1]:


with open('outputAssignment1.txt') as f:
    mylist = [line.rstrip('\n') for line in f]


# In[4]:


query = "London"


# In[3]:


for pair in mylist:
    pair = pair.split(",")
    city = pair[0]
    numberOfStarbucks = pair[1]
    if query == city:
        print(numberOfStarbucks)
    


# In[ ]:




